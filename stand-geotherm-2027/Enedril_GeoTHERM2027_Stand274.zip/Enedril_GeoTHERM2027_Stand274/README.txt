GEOTHERM 2027 - OFFENBURG - STAND 274 - ENEDRIL
Show: 25-26 February 2027 | Set-up: 23-24 February | Orders before 11 December 2026

00_Visual_Pack        3-page A3 PDF: 3D visual, floor plan and layout, list of files to print.
01_Back_wall          4 panels 1000 x 2500 mm (dark blue, white logo) + the 6 m wall at 1:10. Pos. 105058.
02_Storage_face_Our_services   2 panels 1000 x 2500 mm, "Our services" visual (white background). Pos. 105058.
03_Fascia             Lettering 2000 x 299 mm: A = logo + services (centre), B = logo only (left and right).
04_Bar_banners        2 counter banners 950 x 800 mm (95 x 80 cm, pos. 105059): one with the logo, one with the QR code.
05_Roll_ups           Enedril roll-ups 850 x 2000 mm: Directional Drilling and MWD BOOST, standing perpendicular to the storage face.
                      The Fixndril (co-exhibitor) roll-up is supplied by Fixndril.
06_Logo               Official Enedril logo: vector SVG (colour / white, with or without tagline), 6000 px PNG, official source image.
07_3D_Visual         3D visual of the stand (3840 x 2160): 2 Enedril roll-ups, Fixndril roll-up, 2 high tables, blue carpet.
08_Exhibitor_booklet  Messe Offenburg service guide, filled in: system stand type 3, blue carpet, "Our services" storage face,
                      2 high tables (107021 x2) and 6 high stools (107004 x6), co-exhibitor Fixndril.

All print files are vector PDF at final size. The QR code opens https://www.enedril.com.
No bleed or crop marks: to confirm with Messe Offenburg or the printer.
